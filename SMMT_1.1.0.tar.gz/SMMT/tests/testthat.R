
if (require(testthat) & require(tibble) & require(dplyr))
  test_check("SMMT")
